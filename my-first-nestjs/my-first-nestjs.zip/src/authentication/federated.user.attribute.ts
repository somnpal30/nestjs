export class FederatedUserAttribute {
  name :string;
  value :string[];
}